import javax.swing.JCheckBox;

public class MeuCheckBox extends JCheckBox {

	private static final long serialVersionUID = 1L;
	
	public MeuCheckBox(String texto) {
		super(texto);	
	}

}
